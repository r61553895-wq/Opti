package com.maxperf;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Применяет максимально "быстрые" настройки один раз при первом запуске.
 * Чтобы применить заново - удали файл config/maxperf.applied
 */
public class MaxPerfClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("maxperf");

    @Override
    public void onInitializeClient() {
        ClientLifecycleEvents.CLIENT_STARTED.register(MaxPerfClient::apply);
    }

    private static void apply(MinecraftClient client) {
        try {
            Path marker = FabricLoader.getInstance().getConfigDir().resolve("maxperf.applied");
            if (Files.exists(marker)) {
                return;
            }

            GameOptions o = client.options;

            o.getMaxFps().setValue(260);              // 260 = без ограничения
            o.getEnableVsync().setValue(false);
            o.getGraphicsMode().setValue(GraphicsMode.FAST);
            o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
            o.getParticles().setValue(ParticlesMode.MINIMAL);
            o.getAo().setValue(false);
            o.getEntityShadows().setValue(false);
            o.getBobView().setValue(false);
            o.getBiomeBlendRadius().setValue(0);
            o.getMipmapLevels().setValue(0);
            o.getViewDistance().setValue(8);
            o.getSimulationDistance().setValue(5);
            o.getEntityDistanceScaling().setValue(0.5);

            o.write();
            Files.writeString(marker, "applied");
            LOGGER.info("MaxPerf: performance settings applied");
        } catch (Throwable t) {
            LOGGER.error("MaxPerf: failed to apply settings", t);
        }
    }
}
