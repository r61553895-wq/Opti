# MaxPerf (Fabric 1.21.4)

Клиентский мод: при первом запуске ставит самые FPS-ориентированные настройки.
Повторно применить: удали `config/maxperf.applied`.

## Сборка
Положи build.yml в папку .github/workflows/ репозитория, запушь -> вкладка Actions -> артефакты:
- `maxperf-mod` - jar мода
- `maxperf-pack-all-mods` - jar мода + Sodium, Lithium, FerriteCore, ImmediatelyFast, EntityCulling, MoreCulling, ModernFix, Krypton, C2ME, ScalableLux, Noisium + Fabric API

Релиз: `git tag v1.0.0 && git push --tags` - jar появится в Releases.

Локально: `gradle build` (нужен Gradle 8.12+ и Java 21) -> `build/libs/`.

## JVM-аргументы (Launcher -> JVM Arguments)
-Xms4G -Xmx4G -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=50 -XX:+AlwaysPreTouch
